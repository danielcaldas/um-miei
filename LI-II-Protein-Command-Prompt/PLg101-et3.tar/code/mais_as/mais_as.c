#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int mais_as(char *s);

int main ()
{
   char s[5000];
   int n;

   n=scanf("%s", s);
   if(n!=0)
     mais_as(s);
   return 0;
}

int mais_as(char *s)
{
   int i;
   int conta_As=0;
   int comprimento_da_string=strlen(s);

   for(i=0; s[i]!='\0'; i++)
      if(s[i]=='A') conta_As++;

   if(conta_As>=(comprimento_da_string/2) && conta_As!=0) return 1;
   
   return 0;
   
}

