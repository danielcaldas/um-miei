Considerações para utilização da API:

_ É extremamente aconcelhável correr a API num sistema UNIX e com a janela do terminal totalmente expandida para que a formatação do texto
apresentado seja a desenhada pelos programadores;

_No início da API pede-se que se insira o número da opção para poupar ao utilizador o tempo de escrever o nome do ficheiro manualmente
contudo também essa opção é disponibilizada (opção número 4);

_ Note-se bem o facto de que a quando se inicia a aplicação, caso se pretenda inserir manualmente o nome do ficheiro
este deverá conter o ".txt" (mesmo tratamento para inseir nome do ficheiro na querie 10.);

_ A querie extra 101 apenas funcionará corretamente se a máquina tiver instalado o TeX Live (pdflatex), visto que o código da querie
gera automaticamente através de chamadas ao sistema o ficheiro com extenção .pdf  fichadoautor.pdf.

*OBRIGADO!*